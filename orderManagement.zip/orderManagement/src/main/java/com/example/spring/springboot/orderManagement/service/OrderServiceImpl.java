package com.example.spring.springboot.orderManagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.spring.springboot.orderManagement.model.Order;
import com.example.spring.springboot.orderManagement.repository.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService {
	@Autowired
	OrderRepository orderRepository;

	@Override
	public Order createOrder(Order order) {
		return orderRepository.save(order);
	}

	@Override
	public Order getOrderById(int orderId) {
		return orderRepository.findById(orderId).orElse(null);
	}

	@Override
	public List<Order> viewAllOrders() {
		return orderRepository.findAll();
	}

	@Override
	public Order replaceOrder(Order newOrder, int oId) {
		return orderRepository.findById(oId).map(order -> {
			order.setCustomerId(newOrder.getCustomerId());
			order.setName(newOrder.getName());
			order.setEmail(newOrder.getEmail());
			order.setMobileNo(newOrder.getMobileNo());
			order.setProductName(newOrder.getProductName());
			order.setPrice(newOrder.getPrice());
			return orderRepository.save(order);
		}).orElseGet(() -> {
			newOrder.setoId(oId);
			return orderRepository.save(newOrder);
		});
	}

	@Override
	public String delete(int orderId) {
		orderRepository.deleteById(orderId);
		return "Deleted Successfully";
	}
}
