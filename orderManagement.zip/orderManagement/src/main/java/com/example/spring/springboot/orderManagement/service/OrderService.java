package com.example.spring.springboot.orderManagement.service;

import java.util.List;

import com.example.spring.springboot.orderManagement.model.Order;

public interface OrderService 
{
	Order createOrder(Order order);
	Order replaceOrder(Order newOrder,int oId);
	Order getOrderById(int orderId);
	List<Order> viewAllOrders();
	String delete(int orderId);
}
