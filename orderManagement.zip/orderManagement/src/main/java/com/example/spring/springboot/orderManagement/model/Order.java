package com.example.spring.springboot.orderManagement.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="order1")
public class Order 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int oId;
	

	private String productName;
	private Double price;
	private int customerId;
	private String name;
	private String email;
	private String mobileNo;
	
	public Order(int oId, String productName, Double price, int customerId, String name, String email,
			String mobileNo) {
		super();
		this.oId = oId;
		this.productName = productName;
		this.price = price;
		this.customerId = customerId;
		this.name = name;
		this.email = email;
		this.mobileNo = mobileNo;
	}

	public Order(String productName, Double price, int customerId, String name, String email, String mobileNo) {
		super();
		this.productName = productName;
		this.price = price;
		this.customerId = customerId;
		this.name = name;
		this.email = email;
		this.mobileNo = mobileNo;
	}

	public Order() {
		super();
	}

	@Override
	public String toString() {
		return "Order [oId=" + oId + ", productName=" + productName + ", price=" + price + ", customerId=" + customerId
				+ ", name=" + name + ", email=" + email + ", mobileNo=" + mobileNo + "]";
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getName() {
		return name;
	}

	public int getoId() {
		return oId;
	}

	public void setoId(int oId) {
		this.oId = oId;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
}
